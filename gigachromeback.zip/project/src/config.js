export const API_CONFIG = {
  BASE_URL: 'https://api.trygigadesk.com/v1',
  ENDPOINTS: {
    AUTH: '/auth',
    TRANSCRIBE: '/transcribe',
    SUMMARIZE: '/summarize'
  }
};